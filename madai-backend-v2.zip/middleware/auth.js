const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Organization = require("../models/Organization");
const { PLANS, effectivePlan } = require("../config/plans");

async function requireAuth(req, res, next) {
  let payload;
  try {
    const token = req.cookies?.madai_session;
    if (!token) return res.status(401).json({ error: "Authentication required" });
    payload = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ["HS256"] });
  } catch {
    return res.status(401).json({ error: "Invalid or expired session" });
  }
  try {
    if (payload.purpose) return res.status(401).json({ error: "Invalid or expired session" }); // verify/reset tokens are not sessions
    const u = await User.findById(payload.sub);
    if (!u || !u.active || (u.tokenVersion || 0) !== (payload.v || 0)) {
      return res.status(401).json({ error: "Account unavailable" });
    }
    req.user = u;
    req.org = u.org ? await Organization.findById(u.org) : null;
    req.plan = effectivePlan(u, req.org);
    req.limits = PLANS[req.plan] || PLANS.free;
    next();
  } catch (e) {
    next(e);
  }
}

function requireFounder(req, res, next) {
  if (req.user?.role !== "founder") return res.status(403).json({ error: "Founder access required" });
  next();
}

module.exports = { requireAuth, requireFounder };
