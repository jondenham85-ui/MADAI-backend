const rateLimit = require("express-rate-limit");
const { ipKeyGenerator } = rateLimit;

const common = { standardHeaders: "draft-7", legacyHeaders: false };
const byUser = (req) => (req.user?.id ? `u:${req.user.id}` : ipKeyGenerator(req.ip));

module.exports = {
  globalLimiter: rateLimit({ ...common, windowMs: 15 * 60 * 1000, limit: 600 }),
  loginLimiter: rateLimit({ ...common, windowMs: 15 * 60 * 1000, limit: 10, skipSuccessfulRequests: true,
    message: { error: "Too many attempts. Try again later." } }),
  signupLimiter: rateLimit({ ...common, windowMs: 60 * 60 * 1000, limit: 10,
    message: { error: "Too many sign-ups from this network. Try again later." } }),
  emailLimiter: rateLimit({ ...common, windowMs: 60 * 60 * 1000, limit: 8,
    message: { error: "Too many email requests. Try again later." } }),
  aiLimiter: rateLimit({ ...common, windowMs: 60 * 1000, limit: 20, keyGenerator: byUser,
    message: { error: "Slow down a little and try again in a minute." } }),
  billingLimiter: rateLimit({ ...common, windowMs: 15 * 60 * 1000, limit: 30, keyGenerator: byUser }),
};
