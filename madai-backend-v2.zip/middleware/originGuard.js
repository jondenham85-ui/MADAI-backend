// CSRF defence for cookie auth: state-changing browser requests must come from an allowed origin.
const { allowedOrigins } = require("../config/origins");

const originOf = (url) => { try { return new URL(url).origin; } catch { return null; } };

module.exports = (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const src = req.headers.origin || (req.headers.referer ? originOf(req.headers.referer) : null);
  if (!src) return next(); // non-browser client (curl, server-to-server): no ambient cookies to abuse
  if (allowedOrigins.includes(src)) return next();
  res.status(403).json({ error: "Origin not allowed" });
};
