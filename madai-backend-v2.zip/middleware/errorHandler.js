const prod = process.env.NODE_ENV === "production";

module.exports = (err, req, res, next) => {
  if (res.headersSent) return next(err);
  let status = err.status || err.statusCode || 500;
  let message = err.message;

  if (err.name === "ValidationError") {
    status = 400; message = Object.values(err.errors || {}).map((e) => e.message).join(", ") || "Invalid input";
  } else if (err.name === "CastError") {
    status = 400; message = `Invalid ${err.path || "value"}`;
  } else if (err.code === 11000) {
    status = 409; message = "Already exists";
  } else if (String(err.type || "").startsWith("Stripe")) {
    console.error("Stripe error:", err.message);
    status = 502; message = "Billing provider error. Please try again.";
  }

  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && prod ? "Internal server error" : message });
};
