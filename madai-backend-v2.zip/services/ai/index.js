const OpenAI = require("openai");

class OpenAIProvider {
  constructor() {
    if (!process.env.OPENAI_API_KEY) throw Object.assign(new Error("AI is not configured"), { status: 503 });
    this.client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 120000, maxRetries: 1 });
  }
  async generate({ input, instructions, maxTokens = 4000 }) {
    try {
      const r = await this.client.responses.create({
        model: process.env.OPENAI_MODEL || "gpt-5.5", instructions, input, max_output_tokens: maxTokens });
      if (!r.output_text) throw new Error("Empty response");
      return r.output_text;
    } catch (e) {
      // never forward provider statuses (a 401 here would look like "logged out" to the frontend)
      console.error("AI provider error:", e.status || "", e.message);
      throw Object.assign(new Error("The AI service is temporarily unavailable. Please try again."), { status: 502 });
    }
  }
}

let instance;
function provider() {
  if ((process.env.AI_PROVIDER || "openai") !== "openai") throw Object.assign(new Error("AI provider not configured"), { status: 503 });
  return (instance ??= new OpenAIProvider());
}
module.exports = { provider };
