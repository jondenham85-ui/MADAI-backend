const User = require("../models/User");
const Organization = require("../models/Organization");
const { PLANS, isBusinessPlan, planFromPriceId, PAID_PLANS } = require("../config/plans");

const LIVE = ["active", "trialing", "past_due"];            // past_due = grace while Stripe retries payment
const DEAD = ["canceled", "unpaid", "incomplete_expired"];

// Keep Organization + role in step with the user's personal plan.
async function syncOrg(user) {
  if (isBusinessPlan(user.plan)) {
    const org = await Organization.findOneAndUpdate(
      { owner: user._id },
      { $set: { plan: user.plan }, $setOnInsert: { name: `${user.name}'s team` } },
      { upsert: true, new: true, setDefaultsOnInsert: true });
    const set = { org: org._id };
    if (user.role !== "founder") set.role = "business";
    await User.updateOne({ _id: user._id }, { $set: set });
    // plan downgraded within business tiers: drop newest members beyond the seat count
    const seats = PLANS[user.plan].seats;
    const members = await User.find({ org: org._id, _id: { $ne: user._id } })
      .sort({ orgJoinedAt: 1, _id: 1 }).select("_id");
    const extra = members.slice(Math.max(seats - 1, 0));
    if (extra.length) await User.updateMany({ _id: { $in: extra.map((x) => x._id) } }, { $set: { org: null } });
  } else {
    const org = await Organization.findOne({ owner: user._id });
    if (org) {
      org.plan = "free";
      await org.save();
      await User.updateMany({ org: org._id }, { $set: { org: null } }); // members lose team access
    }
    if (user.role === "business") await User.updateOne({ _id: user._id }, { $set: { role: "consumer" } });
  }
}

async function applySubscription(sub, userIdHint) {
  const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer?.id;
  const user = (await User.findOne({ stripeSubscriptionId: sub.id }))
    || (userIdHint && (await User.findById(userIdHint)))
    || (customerId && (await User.findOne({ stripeCustomerId: customerId })));
  if (!user) { console.warn("Stripe subscription with no matching user:", sub.id); return; }

  const item = sub.items?.data?.[0];
  const plan = planFromPriceId(item?.price?.id)
    || (PAID_PLANS[sub.metadata?.plan] ? sub.metadata.plan : null);

  if (LIVE.includes(sub.status)) {
    if (!plan) { console.error("Unknown Stripe price for subscription", sub.id); return; }
    user.plan = plan;
    user.stripeSubscriptionId = sub.id;
    user.stripeCustomerId = customerId || user.stripeCustomerId;
    user.subscriptionStatus = sub.status;
    user.cancelAtPeriodEnd = !!sub.cancel_at_period_end;
    const end = item?.current_period_end ?? sub.current_period_end;
    user.currentPeriodEnd = end ? new Date(end * 1000) : undefined;
  } else if (DEAD.includes(sub.status)) {
    // ignore late events for an old subscription when a newer one is already stored
    if (user.stripeSubscriptionId && user.stripeSubscriptionId !== sub.id) return;
    user.plan = "free";
    user.stripeSubscriptionId = undefined;
    user.subscriptionStatus = sub.status;
    user.cancelAtPeriodEnd = false;
    user.currentPeriodEnd = undefined;
  } else {
    return; // incomplete / paused: no change
  }
  await user.save();
  await syncOrg(user);
}

module.exports = { applySubscription, syncOrg };
