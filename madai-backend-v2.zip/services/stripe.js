const Stripe = require("stripe");
let client;
function stripe() {
  if (!process.env.STRIPE_SECRET_KEY) throw Object.assign(new Error("Billing is not configured"), { status: 503 });
  return (client ??= new Stripe(process.env.STRIPE_SECRET_KEY));
}
module.exports = { stripe };
