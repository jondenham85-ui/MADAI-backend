const Usage = require("../models/Usage");
const User = require("../models/User");

const iso = () => new Date().toISOString();
const PERIOD = { chat: () => `d:${iso().slice(0, 10)}`, task: () => `m:${iso().slice(0, 7)}`, build: () => `m:${iso().slice(0, 7)}` };
const BONUS = { task: "bonusTasks", build: "bonusBuilds" };

async function bump(userId, period, field, delta) {
  const run = () => Usage.findOneAndUpdate({ user: userId, period }, { $inc: { [field]: delta } },
    { upsert: true, new: true, setDefaultsOnInsert: true });
  try { return await run(); }
  catch (e) { if (e.code === 11000) return run(); throw e; } // concurrent first-write race
}

// Take one unit: monthly/daily allowance first, then Mad Pack credits (tasks/builds only).
// Returns { ok, usedBonus }. Pass usedBonus back to refund() if the work then fails.
async function consume(userId, field, limit) {
  const period = PERIOD[field]();
  const doc = await bump(userId, period, field, 1);
  if (doc[field] <= limit) return { ok: true, usedBonus: false };
  await bump(userId, period, field, -1);
  if (BONUS[field]) {
    const hit = await User.findOneAndUpdate({ _id: userId, [BONUS[field]]: { $gt: 0 } }, { $inc: { [BONUS[field]]: -1 } });
    if (hit) return { ok: true, usedBonus: true };
  }
  return { ok: false, usedBonus: false };
}

async function refund(userId, field, usedBonus) {
  try {
    if (usedBonus) await User.updateOne({ _id: userId }, { $inc: { [BONUS[field]]: 1 } });
    else await bump(userId, PERIOD[field](), field, -1);
  } catch { /* best effort */ }
}

async function summary(userId) {
  const [d, m] = await Promise.all([
    Usage.findOne({ user: userId, period: PERIOD.chat() }).lean(),
    Usage.findOne({ user: userId, period: PERIOD.task() }).lean(),
  ]);
  return { chatToday: d?.chat || 0, tasksThisMonth: m?.task || 0, buildsThisMonth: m?.build || 0 };
}

function monthlyResetAt() {
  const n = new Date();
  return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth() + 1, 1)).toISOString();
}

module.exports = { consume, refund, summary, monthlyResetAt };
