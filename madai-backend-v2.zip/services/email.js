// Sends transactional email through Resend (https://resend.com). No extra dependency; uses Node's fetch.
async function sendEmail({ to, subject, text, html }) {
  const key = process.env.RESEND_API_KEY, from = process.env.EMAIL_FROM;
  if (!key || !from) {
    if (process.env.NODE_ENV === "production") console.warn("Email not configured (RESEND_API_KEY / EMAIL_FROM): not sent to", to);
    else console.log(`\n[dev email] to=${to}\n${subject}\n${text}\n`);   // dev only: lets you click links locally
    return false;
  }
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [to], subject, text, html: html || `<p>${text.replace(/\n/g, "<br>")}</p>` }),
  });
  if (!res.ok) { console.error("Email send failed:", res.status, await res.text().catch(() => "")); return false; }
  return true;
}
module.exports = { sendEmail };
