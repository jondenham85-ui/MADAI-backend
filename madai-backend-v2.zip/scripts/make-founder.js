// Usage (locally, with MONGODB_URI in .env):  npm run make-founder -- you@example.com
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../models/User");

(async () => {
  const email = (process.argv[2] || "").trim().toLowerCase();
  if (!email) { console.error("Usage: npm run make-founder -- email@example.com"); process.exit(1); }
  await mongoose.connect(process.env.MONGODB_URI);
  const u = await User.findOneAndUpdate({ email }, { role: "founder", emailVerified: true }, { new: true });
  console.log(u ? `${u.email} is now a founder` : "No account with that email. Sign up first, then run this again.");
  await mongoose.disconnect();
})().catch((e) => { console.error(e.message); process.exit(1); });
