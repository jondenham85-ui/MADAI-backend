// Syntax-checks every .js file (no dependencies needed)
const { readdirSync, statSync } = require("fs");
const { join } = require("path");
const { spawnSync } = require("child_process");
let bad = 0;
(function walk(dir) {
  for (const f of readdirSync(dir)) {
    if (f === "node_modules" || f.startsWith(".")) continue;
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p);
    else if (f.endsWith(".js") && spawnSync(process.execPath, ["--check", p], { stdio: "inherit" }).status) bad++;
  }
})(join(__dirname, ".."));
console.log(bad ? `${bad} file(s) failed` : "All files OK");
process.exit(bad ? 1 : 0);
