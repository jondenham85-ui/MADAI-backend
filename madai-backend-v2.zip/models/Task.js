const m = require("mongoose");
module.exports = m.model("Task", new m.Schema({
  owner: { type: m.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 160 },
  completed: { type: Boolean, default: false },
  priority: { type: String, enum: ["low", "medium", "high"], default: "medium" },
  dueAt: Date,
}, { timestamps: true }));
