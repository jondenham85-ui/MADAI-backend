const m = require("mongoose");
// Idempotency ledger: Stripe may deliver an event more than once.
module.exports = m.model("StripeEvent", new m.Schema({
  _id: { type: String },
  createdAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 30 },
}));
