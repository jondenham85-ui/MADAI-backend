const m = require("mongoose");
module.exports = m.model("Project", new m.Schema({
  owner: { type: m.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 120 },
  kind: { type: String, enum: ["general", "website", "webapp", "code", "business"], default: "general" },
  prompt: { type: String, maxlength: 8000 },
  status: { type: String, enum: ["draft", "active", "complete"], default: "draft" },
  artifact: { type: String, default: "" },
}, { timestamps: true }));
