const m = require("mongoose");
module.exports = m.model("Conversation", new m.Schema({
  owner: { type: m.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, default: "New conversation" },
  messages: [{ role: { type: String, enum: ["user", "assistant"] }, content: String, createdAt: { type: Date, default: Date.now } }],
}, { timestamps: true }));
