const m = require("mongoose");
const { ASSIGNABLE } = require("../config/plans");

const s = new m.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  emailVerified: { type: Boolean, default: false },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ["consumer", "business", "founder"], default: "consumer" },
  plan: { type: String, enum: ASSIGNABLE, default: "free" },
  bonusTasks: { type: Number, default: 0, min: 0 },       // Mad Pack credits, used after the monthly allowance
  bonusBuilds: { type: Number, default: 0, min: 0 },
  stripeCustomerId: { type: String, index: true },
  stripeSubscriptionId: { type: String, index: true },
  subscriptionStatus: String,
  cancelAtPeriodEnd: { type: Boolean, default: false },
  currentPeriodEnd: Date,
  org: { type: m.Schema.Types.ObjectId, ref: "Organization", index: true },
  orgJoinedAt: Date,
  tokenVersion: { type: Number, default: 0 },             // bump to invalidate all sessions
  active: { type: Boolean, default: true },
  lastLoginAt: Date,
}, { timestamps: true });

module.exports = m.model("User", s);
