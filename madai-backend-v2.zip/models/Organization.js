const m = require("mongoose");
const { ASSIGNABLE } = require("../config/plans");

module.exports = m.model("Organization", new m.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  owner: { type: m.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
  plan: { type: String, enum: ASSIGNABLE, default: "free" },
}, { timestamps: true }));
