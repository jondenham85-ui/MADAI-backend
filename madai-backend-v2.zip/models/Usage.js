const m = require("mongoose");
// One doc per user per period. period = "d:YYYY-MM-DD" (chat) or "m:YYYY-MM" (tasks, builds), UTC.
const s = new m.Schema({
  user: { type: m.Schema.Types.ObjectId, ref: "User", required: true },
  period: { type: String, required: true },
  chat: { type: Number, default: 0 },
  task: { type: Number, default: 0 },
  build: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 40 },
});
s.index({ user: 1, period: 1 }, { unique: true });
module.exports = m.model("Usage", s);
