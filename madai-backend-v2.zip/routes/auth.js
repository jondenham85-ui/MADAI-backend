const r = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const User = require("../models/User");
const Project = require("../models/Project");
const { loginLimiter, signupLimiter, emailLimiter } = require("../middleware/rateLimiter");
const { sendEmail } = require("../services/email");
const { frontendUrl } = require("../config/origins");
const { requireAuth } = require("../middleware/auth");
const { summary, monthlyResetAt } = require("../services/usage");

const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12); // equalises login timing for unknown emails
const founders = () => new Set((process.env.OWNER_EMAILS || "").split(",").map((x) => x.trim().toLowerCase()).filter(Boolean));
const sha = (v) => crypto.createHash("sha256").update(String(v)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));

const view = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, plan: u.plan, emailVerified: !!u.emailVerified });

function cookieOpts() {
  const sameSite = (process.env.COOKIE_SAMESITE || "lax").toLowerCase();
  return {
    httpOnly: true, path: "/", sameSite,
    secure: process.env.NODE_ENV === "production" || sameSite === "none",
    ...(process.env.COOKIE_DOMAIN ? { domain: process.env.COOKIE_DOMAIN } : {}),
  };
}
function startSession(res, u) {
  const token = jwt.sign({ sub: u.id, v: u.tokenVersion || 0 }, process.env.JWT_SECRET, { expiresIn: "7d", algorithm: "HS256" });
  res.cookie("madai_session", token, { ...cookieOpts(), maxAge: 7 * 24 * 60 * 60 * 1000 });
}
// Single-purpose signed links for email verification and password reset
const makeToken = (u, purpose, expiresIn) =>
  jwt.sign({ sub: u.id, purpose, v: u.tokenVersion || 0, e: u.email }, process.env.JWT_SECRET, { expiresIn, algorithm: "HS256" });
function readToken(t, purpose) {
  try {
    const p = jwt.verify(String(t || ""), process.env.JWT_SECRET, { algorithms: ["HS256"] });
    return p.purpose === purpose ? p : null;
  } catch { return null; }
}
const sendVerification = (u) => sendEmail({ to: u.email, subject: "Verify your MAD AI email",
  text: `Hi ${u.name},\n\nConfirm your email to finish setting up MAD AI:\n${frontendUrl()}/verify-email?token=${makeToken(u, "verify", "2d")}\n\nThis link expires in 2 days. If you didn't sign up, ignore this email.` });

const clearSession = (res) => res.clearCookie("madai_session", cookieOpts());

function passwordProblem(p) {
  if (p.length < 10 || !/[A-Z]/.test(p) || !/[a-z]/.test(p) || !/[0-9]/.test(p)) return "Password needs 10+ characters, uppercase, lowercase, and a number";
  if (p.length > 128) return "Password is too long (128 max)";
  return null;
}

r.post("/signup", signupLimiter, async (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2) return res.status(400).json({ error: "Enter your name" });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email" });
    const problem = passwordProblem(password);
    if (problem) return res.status(400).json({ error: problem });
    if (await User.exists({ email })) return res.status(409).json({ error: "Account already exists" });

    // Founder = email on the owner list AND the private setup code. The email alone is never enough.
    const code = process.env.FOUNDER_SETUP_CODE;
    const role = code && founders().has(email) && safeEqual(req.body.founderCode || "", code) ? "founder" : "consumer";

    const u = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12), role,
      emailVerified: role === "founder" });
    if (!u.emailVerified) sendVerification(u).catch((e) => console.error("verification email failed:", e.message));
    startSession(res, u);
    res.status(201).json({ user: view(u) });
  } catch (e) { next(e); }
});

r.post("/login", loginLimiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const u = await User.findOne({ email }).select("+passwordHash");
    const ok = await bcrypt.compare(password, u?.passwordHash || DUMMY_HASH);
    if (!u || !u.active || !ok) return res.status(401).json({ error: "Invalid email or password" });
    u.lastLoginAt = new Date();
    await u.save();
    startSession(res, u);
    res.json({ user: view(u) });
  } catch (e) { next(e); }
});

r.post("/verify-email", async (req, res, next) => {
  try {
    const p = readToken(req.body.token, "verify");
    const u = p && (await User.findById(p.sub));
    if (!u || u.email !== p.e) return res.status(400).json({ error: "This link is invalid or has expired" });
    if (!u.emailVerified) { u.emailVerified = true; await u.save(); }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

r.post("/resend-verification", requireAuth, emailLimiter, async (req, res, next) => {
  try {
    if (!req.user.emailVerified) await sendVerification(req.user);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// Always answers 200 so it can't be used to discover which emails have accounts
r.post("/forgot-password", emailLimiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const u = await User.findOne({ email });
    if (u && u.active) {
      await sendEmail({ to: u.email, subject: "Reset your MAD AI password",
        text: `Hi ${u.name},\n\nReset your password here:\n${frontendUrl()}/reset-password?token=${makeToken(u, "reset", "1h")}\n\nThis link expires in 1 hour and works once. If you didn't ask for this, ignore this email.` });
    }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

r.post("/reset-password", emailLimiter, async (req, res, next) => {
  try {
    const p = readToken(req.body.token, "reset");
    const u = p && (await User.findById(p.sub).select("+passwordHash"));
    if (!u || !u.active || (u.tokenVersion || 0) !== p.v) return res.status(400).json({ error: "This link is invalid or has expired" });
    const pw = String(req.body.newPassword || "");
    const problem = passwordProblem(pw);
    if (problem) return res.status(400).json({ error: problem });
    u.passwordHash = await bcrypt.hash(pw, 12);
    u.tokenVersion = (u.tokenVersion || 0) + 1;   // makes the link single-use and signs out every device
    u.emailVerified = true;                        // they just proved they control the inbox
    await u.save();
    clearSession(res);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

r.post("/logout", (req, res) => { clearSession(res); res.status(204).end(); });

// Sign out everywhere
r.post("/logout-all", requireAuth, async (req, res, next) => {
  try {
    await User.updateOne({ _id: req.user._id }, { $inc: { tokenVersion: 1 } });
    clearSession(res);
    res.status(204).end();
  } catch (e) { next(e); }
});

r.post("/password", requireAuth, loginLimiter, async (req, res, next) => {
  try {
    const u = await User.findById(req.user.id).select("+passwordHash");
    if (!(await bcrypt.compare(String(req.body.currentPassword || ""), u.passwordHash))) {
      return res.status(401).json({ error: "Current password is incorrect" });
    }
    const next_ = String(req.body.newPassword || "");
    const problem = passwordProblem(next_);
    if (problem) return res.status(400).json({ error: problem });
    u.passwordHash = await bcrypt.hash(next_, 12);
    u.tokenVersion = (u.tokenVersion || 0) + 1; // signs out other devices
    await u.save();
    startSession(res, u);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// Everything the dashboard needs in one call
r.get("/me", requireAuth, async (req, res, next) => {
  try {
    const [usage, activeProjects] = await Promise.all([
      summary(req.user.id),
      Project.countDocuments({ owner: req.user.id, status: { $ne: "complete" } }),
    ]);
    const L = req.limits;
    res.json({
      user: view(req.user),
      plan: { key: req.plan, label: L.label, tier: L.tier,
        limits: { tasksPerMonth: L.tasksPerMonth, buildsPerMonth: L.buildsPerMonth, chatPerDay: L.chatPerDay,
          projects: L.projects, seats: L.seats, buildKinds: L.buildKinds } },
      usage: { ...usage, activeProjects },
      madPackCredits: { tasks: req.user.bonusTasks || 0, builds: req.user.bonusBuilds || 0 },
      monthlyResetsAt: monthlyResetAt(),
      subscription: { status: req.user.subscriptionStatus || null, cancelAtPeriodEnd: req.user.cancelAtPeriodEnd,
        currentPeriodEnd: req.user.currentPeriodEnd || null },
      org: req.org ? { id: req.org.id, name: req.org.name, isOwner: String(req.org.owner) === req.user.id } : null,
    });
  } catch (e) { next(e); }
});

module.exports = r;
