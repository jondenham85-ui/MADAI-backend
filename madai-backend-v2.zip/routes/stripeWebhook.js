const express = require("express");
const { stripe } = require("../services/stripe");
const { applySubscription } = require("../services/subscriptions");
const User = require("../models/User");
const StripeEvent = require("../models/StripeEvent");
const { MADPACKS } = require("../config/plans");

async function grantMadPack(session) {
  if (session.mode !== "payment" || session.metadata?.kind !== "madpack") return;
  if (session.payment_status !== "paid") return;            // async methods fire a later event
  const pack = MADPACKS[session.metadata.pack];
  if (!pack || !session.metadata.userId) return;
  try { await StripeEvent.create({ _id: `madpack:${session.id}` }); }
  catch (e) { if (e.code === 11000) return; throw e; }       // already granted
  await User.findByIdAndUpdate(session.metadata.userId, { $inc: { bonusTasks: pack.tasks, bonusBuilds: pack.builds } });
}

async function handle(event) {
  const obj = event.data.object;
  switch (event.type) {
    case "checkout.session.completed":
      if (obj.mode === "subscription" && obj.subscription) {
        const sub = await stripe().subscriptions.retrieve(obj.subscription);
        await applySubscription(sub, obj.metadata?.userId || obj.client_reference_id);
      } else {
        await grantMadPack(obj);
      }
      break;
    case "checkout.session.async_payment_succeeded":
      await grantMadPack(obj);
      break;
    case "customer.subscription.updated":
    case "customer.subscription.deleted":
      await applySubscription(obj);
      break;
  }
}

module.exports = [
  express.raw({ type: "application/json" }),
  async (req, res) => {
    let event;
    try {
      event = stripe().webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
    } catch (e) {
      return res.status(400).send(`Webhook error: ${e.message}`);
    }
    try { await StripeEvent.create({ _id: event.id }); }
    catch (e) {
      if (e.code === 11000) return res.json({ received: true, duplicate: true });
      console.error(e); return res.status(500).json({ error: "Webhook storage failed" });
    }
    try {
      await handle(event);
      res.json({ received: true });
    } catch (e) {
      console.error("Webhook handler failed:", event.type, e);
      await StripeEvent.deleteOne({ _id: event.id }).catch(() => {}); // let Stripe retry
      res.status(500).json({ error: "Webhook handler failed" });
    }
  },
];
