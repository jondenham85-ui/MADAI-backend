const r = require("express").Router();
const { requireAuth } = require("../middleware/auth");
const { billingLimiter } = require("../middleware/rateLimiter");
const { stripe } = require("../services/stripe");
const { frontendUrl } = require("../config/origins");
const User = require("../models/User");
const { PAID_PLANS, MADPACKS, publicPlans } = require("../config/plans");

// Public: for the pricing page
r.get("/plans", (req, res) => res.json(publicPlans()));

r.use(requireAuth, billingLimiter);
r.use((req, res, next) => {
  if (req.method === "POST" && req.path !== "/portal" && !req.user.emailVerified) {
    return res.status(403).json({ error: "Please verify your email before purchasing.", code: "EMAIL_NOT_VERIFIED" });
  }
  next();
});

async function ensureCustomer(user) {
  if (user.stripeCustomerId) return user.stripeCustomerId;
  const c = await stripe().customers.create({ email: user.email, name: user.name, metadata: { userId: user.id } });
  await User.updateOne({ _id: user._id }, { $set: { stripeCustomerId: c.id } });
  return c.id;
}

r.get("/status", (req, res) => {
  const u = req.user;
  res.json({
    plan: u.plan, effectivePlan: req.plan, subscriptionStatus: u.subscriptionStatus || null,
    cancelAtPeriodEnd: u.cancelAtPeriodEnd, currentPeriodEnd: u.currentPeriodEnd || null,
    madPackCredits: { tasks: u.bonusTasks || 0, builds: u.bonusBuilds || 0 }, canManageBilling: Boolean(u.stripeCustomerId),
  });
});

r.post("/checkout", async (req, res, next) => {
  try {
    const plan = String(req.body.plan || "");
    const price = PAID_PLANS[plan] && process.env[PAID_PLANS[plan]];
    if (!price) return res.status(400).json({ error: "Plan is not available" });
    const u = req.user;
    if (u.stripeSubscriptionId && ["active", "trialing", "past_due"].includes(u.subscriptionStatus)) {
      return res.status(409).json({ error: "You already have a subscription. Use the billing portal to change or cancel it.", code: "USE_PORTAL" });
    }
    const customer = await ensureCustomer(u);
    const s = await stripe().checkout.sessions.create({
      mode: "subscription", customer, line_items: [{ price, quantity: 1 }], allow_promotion_codes: true,
      client_reference_id: u.id,
      success_url: `${frontendUrl()}/dashboard?checkout=success`,
      cancel_url: `${frontendUrl()}/pricing`,
      metadata: { userId: u.id, plan, kind: "subscription" },
      subscription_data: { metadata: { userId: u.id, plan } },
    });
    res.json({ url: s.url });
  } catch (e) { next(e); }
});

// Mad Pack: one-time purchase of extra task + build credits, usable immediately
r.post("/madpack", async (req, res, next) => {
  try {
    const key = String(req.body.pack || "");
    const pack = MADPACKS[key];
    const price = pack && process.env[pack.env];
    if (!price) return res.status(400).json({ error: "That Mad Pack is not available" });
    const customer = await ensureCustomer(req.user);
    const s = await stripe().checkout.sessions.create({
      mode: "payment", customer, line_items: [{ price, quantity: 1 }],
      client_reference_id: req.user.id,
      success_url: `${frontendUrl()}/dashboard?checkout=madpack`,
      cancel_url: `${frontendUrl()}/pricing`,
      metadata: { userId: req.user.id, kind: "madpack", pack: key },
    });
    res.json({ url: s.url });
  } catch (e) { next(e); }
});

r.post("/portal", async (req, res, next) => {
  try {
    if (!req.user.stripeCustomerId) return res.status(400).json({ error: "No billing account yet" });
    const s = await stripe().billingPortal.sessions.create({
      customer: req.user.stripeCustomerId, return_url: `${frontendUrl()}/dashboard` });
    res.json({ url: s.url });
  } catch (e) { next(e); }
});

module.exports = r;
