const r = require("express").Router();
const Project = require("../models/Project");
const { requireAuth } = require("../middleware/auth");
const { aiLimiter } = require("../middleware/rateLimiter");
const { provider } = require("../services/ai");
const { consume, refund, monthlyResetAt } = require("../services/usage");

r.use(requireAuth);

const KINDS = Project.schema.path("kind").enumValues;
const STATUSES = Project.schema.path("status").enumValues;
const activeCount = (owner) => Project.countDocuments({ owner, status: { $ne: "complete" } });
const limitError = (req) => ({
  error: `The ${req.limits.label} plan includes ${req.limits.projects} active project(s). Complete or delete one, or upgrade.`,
  code: "PROJECT_LIMIT",
});

r.get("/", async (req, res, next) => {
  try { res.json({ projects: await Project.find({ owner: req.user.id }).sort({ updatedAt: -1 }) }); }
  catch (e) { next(e); }
});

r.get("/:id", async (req, res, next) => {
  try {
    const p = await Project.findOne({ _id: req.params.id, owner: req.user.id });
    if (!p) return res.status(404).json({ error: "Project not found" });
    res.json({ project: p });
  } catch (e) { next(e); }
});

r.post("/", async (req, res, next) => {
  try {
    const title = String(req.body.title || "").trim();
    if (!title || title.length > 120) return res.status(400).json({ error: "Title required (120 characters max)" });
    const kind = req.body.kind || "general";
    if (!KINDS.includes(kind)) return res.status(400).json({ error: "Invalid project type" });
    if ((await activeCount(req.user.id)) >= req.limits.projects) return res.status(402).json(limitError(req));
    const project = await Project.create({ owner: req.user.id, title, kind, prompt: String(req.body.prompt || "").slice(0, 8000) });
    res.status(201).json({ project });
  } catch (e) { next(e); }
});

r.patch("/:id", async (req, res, next) => {
  try {
    const p = await Project.findOne({ _id: req.params.id, owner: req.user.id });
    if (!p) return res.status(404).json({ error: "Project not found" });
    if (req.body.title !== undefined) {
      const t = String(req.body.title).trim();
      if (!t || t.length > 120) return res.status(400).json({ error: "Invalid title" });
      p.title = t;
    }
    if (req.body.prompt !== undefined) p.prompt = String(req.body.prompt).slice(0, 8000);
    if (req.body.status !== undefined) {
      if (!STATUSES.includes(req.body.status)) return res.status(400).json({ error: "Invalid status" });
      if (p.status === "complete" && req.body.status !== "complete" && (await activeCount(req.user.id)) >= req.limits.projects) {
        return res.status(402).json(limitError(req));
      }
      p.status = req.body.status;
    }
    await p.save();
    res.json({ project: p });
  } catch (e) { next(e); }
});

r.delete("/:id", async (req, res, next) => {
  try {
    const p = await Project.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!p) return res.status(404).json({ error: "Project not found" });
    res.status(204).end();
  } catch (e) { next(e); }
});

r.post("/:id/build", aiLimiter, async (req, res, next) => {
  let taken;
  try {
    const p = await Project.findOne({ _id: req.params.id, owner: req.user.id });
    if (!p) return res.status(404).json({ error: "Project not found" });
    if (!req.limits.buildKinds.includes(p.kind)) {
      return res.status(402).json({ error: "Upgrade to Pro for app and advanced builds", code: "UPGRADE_REQUIRED" });
    }
    taken = await consume(req.user.id, "build", req.limits.buildsPerMonth);
    if (!taken.ok) {
      return res.status(402).json({
        error: "You've used this month's builds. Get a Mad Pack to keep building right now, or upgrade your plan.",
        code: "BUILD_LIMIT", resetsAt: monthlyResetAt() });
    }
    p.artifact = await provider().generate({
      instructions: `You are MAD AI. Produce a practical ${p.kind} specification and starter code. Clearly label files.`,
      input: p.prompt || p.title,
      maxTokens: 12000,
    });
    if (p.status === "draft") p.status = "active";
    await p.save();
    res.json({ project: p });
  } catch (e) {
    if (taken?.ok) await refund(req.user.id, "build", taken.usedBonus);
    next(e);
  }
});

module.exports = r;
