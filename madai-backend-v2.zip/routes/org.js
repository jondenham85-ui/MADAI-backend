const r = require("express").Router();
const User = require("../models/User");
const { requireAuth } = require("../middleware/auth");
const { PLANS } = require("../config/plans");

r.use(requireAuth);

const isOwner = (req) => req.org && String(req.org.owner) === req.user.id;

r.get("/", async (req, res, next) => {
  try {
    if (!req.org) return res.json({ org: null });
    const members = await User.find({ org: req.org.id }).select("name email").sort({ orgJoinedAt: 1, _id: 1 });
    res.json({
      org: { id: req.org.id, name: req.org.name, plan: req.org.plan, seats: PLANS[req.org.plan]?.seats || 1,
        seatsUsed: members.length, isOwner: isOwner(req) },
      members: members.map((m) => ({ id: m.id, name: m.name, email: m.email, isOwner: String(req.org.owner) === m.id })),
    });
  } catch (e) { next(e); }
});

r.patch("/", async (req, res, next) => {
  try {
    if (!isOwner(req)) return res.status(403).json({ error: "Only the team owner can do that" });
    const name = String(req.body.name || "").trim();
    if (!name || name.length > 80) return res.status(400).json({ error: "Invalid team name" });
    req.org.name = name;
    await req.org.save();
    res.json({ org: { id: req.org.id, name } });
  } catch (e) { next(e); }
});

// Add an existing MAD AI user to the team by email
r.post("/members", async (req, res, next) => {
  try {
    if (!isOwner(req)) return res.status(403).json({ error: "Only the team owner can do that" });
    if (req.org.plan === "free") return res.status(402).json({ error: "A business plan is required to add members" });
    const email = String(req.body.email || "").trim().toLowerCase();
    const target = await User.findOne({ email, active: true });
    if (!target) return res.status(404).json({ error: "No MAD AI account with that email. Ask them to sign up first." });
    if (!target.emailVerified) return res.status(409).json({ error: "That account hasn't verified its email yet" });
    if (target.id === req.user.id) return res.status(400).json({ error: "You're already on the team" });
    if (target.org) return res.status(409).json({ error: "That person is already on a team" });
    const used = await User.countDocuments({ org: req.org.id });
    if (used >= PLANS[req.org.plan].seats) {
      return res.status(402).json({ error: "No seats left. Upgrade your plan to add more people.", code: "SEAT_LIMIT" });
    }
    const joined = await User.findOneAndUpdate({ _id: target._id, org: null },
      { $set: { org: req.org._id, orgJoinedAt: new Date() } }, { new: true });
    if (!joined) return res.status(409).json({ error: "That person is already on a team" });
    res.status(201).json({ member: { id: joined.id, name: joined.name, email: joined.email } });
  } catch (e) { next(e); }
});

r.delete("/members/:userId", async (req, res, next) => {
  try {
    if (!isOwner(req)) return res.status(403).json({ error: "Only the team owner can do that" });
    if (req.params.userId === req.user.id) return res.status(400).json({ error: "Owners can't remove themselves" });
    const removed = await User.findOneAndUpdate({ _id: req.params.userId, org: req.org._id }, { $set: { org: null } });
    if (!removed) return res.status(404).json({ error: "Member not found" });
    res.status(204).end();
  } catch (e) { next(e); }
});

r.post("/leave", async (req, res, next) => {
  try {
    if (!req.org) return res.status(400).json({ error: "You're not on a team" });
    if (isOwner(req)) return res.status(400).json({ error: "Owners can't leave. Cancel the subscription in billing instead." });
    await User.updateOne({ _id: req.user._id }, { $set: { org: null } });
    res.status(204).end();
  } catch (e) { next(e); }
});

module.exports = r;
