const r = require("express").Router();
const Task = require("../models/Task");
const { requireAuth } = require("../middleware/auth");
const { consume, refund, summary, monthlyResetAt } = require("../services/usage");

r.use(requireAuth);

const PRIORITIES = ["low", "medium", "high"];
const parseDue = (v) => {
  if (v === null || v === "" || v === undefined) return { ok: true, value: null };
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? { ok: false } : { ok: true, value: d };
};

r.get("/", async (req, res, next) => {
  try {
    const [tasks, u] = await Promise.all([
      Task.find({ owner: req.user.id }).sort({ createdAt: -1 }).limit(1000),
      summary(req.user.id),
    ]);
    res.json({ tasks, allowance: { used: u.tasksThisMonth, limit: req.limits.tasksPerMonth,
      bonus: req.user.bonusTasks || 0, resetsAt: monthlyResetAt() } });
  } catch (e) { next(e); }
});

r.post("/", async (req, res, next) => {
  let taken;
  try {
    const title = String(req.body.title || "").trim();
    if (!title) return res.status(400).json({ error: "Task title required" });
    if (title.length > 160) return res.status(400).json({ error: "Task title too long (160 max)" });
    const priority = req.body.priority || "medium";
    if (!PRIORITIES.includes(priority)) return res.status(400).json({ error: "Invalid priority" });
    const due = parseDue(req.body.dueAt);
    if (!due.ok) return res.status(400).json({ error: "Invalid due date" });

    taken = await consume(req.user.id, "task", req.limits.tasksPerMonth);
    if (!taken.ok) {
      return res.status(402).json({
        error: "You've used this month's tasks. Get a Mad Pack to keep going right now, or upgrade your plan.",
        code: "TASK_LIMIT", resetsAt: monthlyResetAt() });
    }
    const task = await Task.create({ owner: req.user.id, title, priority, dueAt: due.value });
    res.status(201).json({ task });
  } catch (e) {
    if (taken?.ok) await refund(req.user.id, "task", taken.usedBonus);
    next(e);
  }
});

r.patch("/:id", async (req, res, next) => {
  try {
    const set = {};
    if (req.body.completed !== undefined) set.completed = !!req.body.completed;
    if (req.body.title !== undefined) {
      const t = String(req.body.title).trim();
      if (!t || t.length > 160) return res.status(400).json({ error: "Invalid title" });
      set.title = t;
    }
    if (req.body.priority !== undefined) {
      if (!PRIORITIES.includes(req.body.priority)) return res.status(400).json({ error: "Invalid priority" });
      set.priority = req.body.priority;
    }
    if (req.body.dueAt !== undefined) {
      const due = parseDue(req.body.dueAt);
      if (!due.ok) return res.status(400).json({ error: "Invalid due date" });
      set.dueAt = due.value;
    }
    if (!Object.keys(set).length) return res.status(400).json({ error: "Nothing to update" });
    const task = await Task.findOneAndUpdate({ _id: req.params.id, owner: req.user.id }, { $set: set }, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ error: "Task not found" });
    res.json({ task });
  } catch (e) { next(e); }
});

r.delete("/:id", async (req, res, next) => {
  try {
    const t = await Task.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!t) return res.status(404).json({ error: "Task not found" });
    res.status(204).end();
  } catch (e) { next(e); }
});

module.exports = r;
