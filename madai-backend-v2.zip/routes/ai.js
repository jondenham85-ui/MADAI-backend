const r = require("express").Router();
const Conversation = require("../models/Conversation");
const { requireAuth } = require("../middleware/auth");
const { aiLimiter } = require("../middleware/rateLimiter");
const { provider } = require("../services/ai");
const { consume, refund } = require("../services/usage");

r.use(requireAuth, aiLimiter);

r.post("/chat", async (req, res, next) => {
  let taken = false;
  try {
    const msg = String(req.body.message || "").trim();
    if (!msg) return res.status(400).json({ error: "Message required" });
    if (msg.length > 4000) return res.status(400).json({ error: "Message too long (4000 characters max)" });

    const existing = req.body.conversationId
      ? await Conversation.findOne({ _id: req.body.conversationId, owner: req.user.id }) : null;

    if (!(await consume(req.user.id, "chat", req.limits.chatPerDay)).ok) {
      return res.status(429).json({ error: `You've hit today's chat limit for the ${req.limits.label} plan.`, code: "CHAT_LIMIT" });
    }
    taken = true;

    const history = existing ? existing.messages.slice(-12).map((x) => `${x.role}: ${x.content}`).join("\n") : "";
    const text = await provider().generate({
      instructions: "You are MAD AI, a fun, professional creation assistant. Help with websites, web apps, code, projects, business plans, and daily tasks. Never claim an action was completed unless it was.",
      input: `${history}\nuser: ${msg}`,
    });

    const turn = [{ role: "user", content: msg }, { role: "assistant", content: text }];
    let id;
    if (existing) {
      // keep at most 200 messages per conversation
      await Conversation.updateOne({ _id: existing._id }, { $push: { messages: { $each: turn, $slice: -200 } } });
      id = existing.id;
    } else {
      id = (await Conversation.create({ owner: req.user.id, title: msg.slice(0, 60), messages: turn })).id;
    }
    res.json({ conversationId: id, message: text });
  } catch (e) {
    if (taken) await refund(req.user.id, "chat", false);
    next(e);
  }
});

r.get("/conversations", async (req, res, next) => {
  try {
    res.json({ conversations: await Conversation.find({ owner: req.user.id }).select("title updatedAt").sort({ updatedAt: -1 }).limit(30) });
  } catch (e) { next(e); }
});

r.get("/conversations/:id", async (req, res, next) => {
  try {
    const c = await Conversation.findOne({ _id: req.params.id, owner: req.user.id });
    if (!c) return res.status(404).json({ error: "Conversation not found" });
    res.json({ conversation: c });
  } catch (e) { next(e); }
});

r.delete("/conversations/:id", async (req, res, next) => {
  try {
    const c = await Conversation.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
    if (!c) return res.status(404).json({ error: "Conversation not found" });
    res.status(204).end();
  } catch (e) { next(e); }
});

module.exports = r;
