const r = require("express").Router();
const mongoose = require("mongoose");
const User = require("../models/User");
const Task = require("../models/Task");
const Project = require("../models/Project");
const Organization = require("../models/Organization");
const { requireAuth, requireFounder } = require("../middleware/auth");
const { ASSIGNABLE } = require("../config/plans");
const { syncOrg } = require("../services/subscriptions");

r.use(requireAuth, requireFounder);

const FIELDS = "name email role plan active bonusTasks bonusBuilds subscriptionStatus createdAt";
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

r.get("/summary", async (req, res, next) => {
  try {
    const [users, tasks, projects, orgs, plans, recent] = await Promise.all([
      User.countDocuments(), Task.countDocuments(), Project.countDocuments(), Organization.countDocuments({ plan: { $ne: "free" } }),
      User.aggregate([{ $group: { _id: "$plan", count: { $sum: 1 } } }]),
      User.find().select(FIELDS).sort({ createdAt: -1 }).limit(50),
    ]);
    res.json({ counts: { users, tasks, projects, activeTeams: orgs }, plans, recent });
  } catch (e) { next(e); }
});

r.get("/users", async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim().slice(0, 80);
    if (!q) return res.json({ users: [] });
    const rx = new RegExp(esc(q), "i");
    res.json({ users: await User.find({ $or: [{ email: rx }, { name: rx }] }).select(FIELDS).limit(25) });
  } catch (e) { next(e); }
});

// Note: a plan set here is overridden by the next Stripe subscription event for that user.
r.patch("/users/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ error: "Invalid user id" });
    const u = await User.findById(req.params.id);
    if (!u) return res.status(404).json({ error: "User not found" });
    let planChanged = false;
    if (req.body.plan !== undefined) {
      if (!ASSIGNABLE.includes(req.body.plan)) return res.status(400).json({ error: "Invalid plan" });
      planChanged = u.plan !== req.body.plan;
      u.plan = req.body.plan;
    }
    if (typeof req.body.active === "boolean") {
      if (u.id === req.user.id && !req.body.active) return res.status(400).json({ error: "You can't deactivate yourself" });
      u.active = req.body.active;
    }
    if (req.body.bonusTasks !== undefined) {
      const n = Number(req.body.bonusTasks);
      if (!Number.isInteger(n) || n < 0 || n > 1000000) return res.status(400).json({ error: "Invalid bonusTasks" });
      u.bonusTasks = n;
    }
    if (req.body.bonusBuilds !== undefined) {
      const n = Number(req.body.bonusBuilds);
      if (!Number.isInteger(n) || n < 0 || n > 1000000) return res.status(400).json({ error: "Invalid bonusBuilds" });
      u.bonusBuilds = n;
    }
    await u.save();
    if (planChanged) await syncOrg(u);
    res.json({ user: await User.findById(u.id).select(FIELDS) });
  } catch (e) { next(e); }
});

module.exports = r;
