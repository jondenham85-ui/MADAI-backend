require("dotenv").config();
const mongoose = require("mongoose");
const app = require("./app");
const connectDB = require("./config/db");
const port = process.env.PORT || 10000;

(async () => {
  try {
    if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters");
    if (process.env.NODE_ENV === "production") {
      for (const k of ["FRONTEND_URL", "OPENAI_API_KEY", "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET"]) {
        if (!process.env[k]) console.warn(`WARNING: ${k} is not set`);
      }
    }
    await connectDB();
    const server = app.listen(port, "0.0.0.0", () => console.log(`MAD AI API listening on ${port}`));
    const shutdown = () => server.close(async () => { await mongoose.connection.close(); process.exit(0); });
    process.on("SIGTERM", shutdown);
    process.on("SIGINT", shutdown);
  } catch (e) {
    console.error("Startup failed:", e.message);
    process.exit(1);
  }
})();
process.on("unhandledRejection", (e) => console.error("Unhandled rejection:", e));
