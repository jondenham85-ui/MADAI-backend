const test = require("node:test");
const assert = require("node:assert");
const P = require("../config/plans");

test("founders always get founder limits", () => {
  assert.equal(P.effectivePlan({ role: "founder", plan: "free" }, null), "founder");
});
test("team members inherit the org plan; personal plan wins when higher", () => {
  assert.equal(P.effectivePlan({ role: "consumer", plan: "free" }, { plan: "business" }), "business");
  assert.equal(P.effectivePlan({ role: "consumer", plan: "starter" }, { plan: "team" }), "team");
  assert.equal(P.effectivePlan({ role: "consumer", plan: "pro" }, { plan: "free" }), "pro");
  assert.equal(P.effectivePlan({ role: "consumer" }, null), "free");
});
test("every plan has monthly task and build allowances", () => {
  for (const [k, p] of Object.entries(P.PLANS)) {
    assert.ok(p.tasksPerMonth > 0 && p.buildsPerMonth > 0 && p.chatPerDay > 0, k);
  }
  assert.ok(P.PLANS.pro.tasksPerMonth > P.PLANS.starter.tasksPerMonth);
});
test("Mad Packs grant both tasks and builds and get bigger", () => {
  const { small, medium, large } = P.MADPACKS;
  for (const p of [small, medium, large]) assert.ok(p.tasks > 0 && p.builds > 0);
  assert.ok(large.tasks > medium.tasks && medium.tasks > small.tasks);
});
test("price id maps back to plan", () => {
  process.env.STRIPE_PRO_PRICE_ID = "price_pro";
  assert.equal(P.planFromPriceId("price_pro"), "pro");
  assert.equal(P.planFromPriceId("nope"), null);
});
test("business tiers have seats, consumer tiers do not", () => {
  for (const k of ["free", "starter", "pro"]) assert.equal(P.PLANS[k].seats, 1);
  assert.ok(P.PLANS.team.seats > 1 && P.PLANS.growth.seats > P.PLANS.business.seats);
  assert.ok(P.isBusinessPlan("team") && !P.isBusinessPlan("pro"));
});
test("public plans hide founder and flag unconfigured prices", () => {
  const { plans, madPacks } = P.publicPlans();
  assert.ok(!plans.find((p) => p.key === "founder"));
  assert.equal(plans.find((p) => p.key === "free").available, true);
  assert.equal(madPacks.length, 3);
});
