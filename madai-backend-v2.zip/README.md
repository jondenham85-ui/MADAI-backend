# MAD AI Backend v2
Express + MongoDB Atlas + OpenAI + Stripe. Frontend on Vercel, backend on Render.

## Plans (edit numbers in `config/plans.js`)
Tasks and builds are **monthly allowances** (reset on the 1st, UTC). Chat resets daily.
| Plan | Tier | Tasks/mo | Builds/mo | Chat/day | Projects | Seats |
|---|---|---|---|---|---|---|
| Free | consumer | 20 | 3 (website only) | 25 | 1 | 1 |
| Starter | consumer | 100 | 15 (website only) | 150 | 5 | 1 |
| Pro | consumer | 1,000 | 60 | 500 | 25 | 1 |
| Team | business | 2,000 / member | 120 | 600 | 50 | 5 |
| Business | business | 5,000 / member | 300 | 1,000 | 100 | 15 |
| Growth | business | 10,000 / member | 900 | 2,000 | 250 | 50 |

**Mad Packs** are one-time purchases of extra credits, so nobody waits for the monthly reset:
| Pack | Tasks | Builds |
|---|---|---|
| Mad Pack S | +25 | +3 |
| Mad Pack M | +100 | +10 |
| Mad Pack L | +500 | +50 |

Credits are used only after the monthly allowance runs out, never expire, and work on any plan including Free. They belong to the buyer personally (not shared with a team). If a task or build fails, the credit is refunded.
Business owners add teammates by email (they must already have a MAD AI account). Members get the team plan's limits; removing a member or cancelling returns them to their own plan.

## Deploy
### 1. Render
Push to GitHub, create a Render Blueprint from `render.yaml`, fill every `sync: false` variable (see `.env.example`). Health check: `/api/health`.
Free Render instances sleep when idle, so the first request after a nap is slow. Ping `/api/health` every 5 minutes with a free uptime monitor, or move to a paid instance.

### 2. Connect Vercel to Render (pick one)
**A. Custom domains (recommended).** Frontend `madmadisonai.com` on Vercel, API `api.madmadisonai.com` on Render (Render > Custom Domains).
Set `FRONTEND_URL=https://madmadisonai.com`, `COOKIE_SAMESITE=lax`, `TRUST_PROXY_HOPS=1`. The frontend must call the API with `credentials: "include"`.
**B. Vercel rewrite.** In the frontend `vercel.json`:
`{ "rewrites": [{ "source": "/api/:path*", "destination": "https://YOUR-SERVICE.onrender.com/api/:path*" }] }`
then call `/api/...` on your own domain, keep `COOKIE_SAMESITE=lax`, and set `TRUST_PROXY_HOPS=2`. Test a long AI build through it before relying on it.
Avoid plain `*.vercel.app` + `*.onrender.com` with `COOKIE_SAMESITE=none`: Safari and Brave block those cookies.

### 3. Email (logins)
Sign up at resend.com, verify your sending domain, and set `RESEND_API_KEY` and `EMAIL_FROM`. Without them, verification and reset emails aren't sent (in development the link prints in the server log).
Your frontend needs two pages: `/verify-email?token=...` (POST the token to `/api/auth/verify-email`) and `/reset-password?token=...` (POST `{token,newPassword}` to `/api/auth/reset-password`).
Unverified users can chat and use tasks, but can't purchase or be added to a team.

### 4. Stripe
1. Create 5 recurring Prices (Starter, Pro, Team, Business, Growth) and 3 one-time Prices (Mad Pack S/M/L). Put the IDs in the env vars.
2. Webhook endpoint `https://<api-host>/api/billing/webhook` with events:
   `checkout.session.completed`, `checkout.session.async_payment_succeeded`, `customer.subscription.updated`, `customer.subscription.deleted`.
3. Settings > Billing > Customer portal: enable cancel and plan switching for the 5 recurring prices. This is how people upgrade, downgrade and cancel.
4. Cancellations and failed payments are handled automatically. `past_due` keeps access while Stripe retries, then drops to Free.

### 5. Founder accounts (you and your wife)
Set `OWNER_EMAILS` and a long random `FOUNDER_SETUP_CODE`. When you sign up, send `founderCode` in the signup body (add a hidden field on a private page, or call the API once with curl). Founders get unlimited limits.
Alternative: sign up normally, then run locally `npm run make-founder -- you@example.com` with your `MONGODB_URI` in `.env`.

## API for the frontend
All requests need `credentials: "include"`. Errors are `{ error, code? }`. Codes: `CHAT_LIMIT` (429), `BUILD_LIMIT` and `TASK_LIMIT` (402, show the Mad Pack / upgrade prompt; body includes `resetsAt`), `PROJECT_LIMIT`, `SEAT_LIMIT`, `UPGRADE_REQUIRED`, `USE_PORTAL`, `EMAIL_NOT_VERIFIED`.

| Route | Purpose |
|---|---|
| POST `/api/auth/signup` `{name,email,password,founderCode?}` · `/login` · `/logout` · `/logout-all` · `/password` | accounts |
| POST `/api/auth/verify-email` `{token}` · `/resend-verification` · `/forgot-password` `{email}` · `/reset-password` `{token,newPassword}` | email verification and password reset |
| GET `/api/auth/me` | user + plan limits + usage + Mad Pack credits + subscription + team (one call for the dashboard) |
| GET `/api/billing/plans` | public, for the pricing page (plans, limits, Mad Packs, `available`) |
| POST `/api/billing/checkout` `{plan}` · `/madpack` `{pack: small\|medium\|large}` · `/portal` | return `{url}` to redirect to |
| GET `/api/billing/status` | subscription state |
| POST `/api/ai/chat` `{message,conversationId?}` · GET `/api/ai/conversations[/:id]` · DELETE `/:id` | chat |
| GET/POST `/api/tasks` · PATCH/DELETE `/api/tasks/:id` | tasks (GET includes `allowance: {used, limit, bonus, resetsAt}`) |
| GET/POST `/api/projects` · GET/PATCH/DELETE `/:id` · POST `/:id/build` | projects |
| GET `/api/org` · PATCH `/api/org` · POST `/api/org/members` `{email}` · DELETE `/members/:userId` · POST `/leave` | business teams |
| GET `/api/founder/summary` · `/users?q=` · PATCH `/users/:id` `{plan?, active?, bonusTasks?, bonusBuilds?}` | founder admin |

## Dev
`npm install`, copy `.env.example` to `.env`, `npm run dev`. `npm test` runs the plan-logic tests; `npm run check` syntax-checks every file.
Never commit `.env`.
