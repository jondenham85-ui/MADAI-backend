const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const { globalLimiter } = require("./middleware/rateLimiter");
const originGuard = require("./middleware/originGuard");
const errorHandler = require("./middleware/errorHandler");
const { allowedOrigins } = require("./config/origins");

const app = express();
const prod = process.env.NODE_ENV === "production";

app.disable("x-powered-by");
// Render adds 1 proxy hop. If the browser reaches the API through a Vercel rewrite, set TRUST_PROXY_HOPS=2.
if (prod) app.set("trust proxy", Number(process.env.TRUST_PROXY_HOPS || 1));

app.use(helmet());
app.use(morgan(prod ? "combined" : "dev"));
// Health check sits before rate limiting so Render's probes can never be throttled
app.get("/api/health", (req, res) => res.json({ status: "online", service: "MAD AI API", version: "2.0.0", timestamp: new Date().toISOString() }));

app.use(cors({
  origin(origin, cb) {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(Object.assign(new Error("Origin not allowed"), { status: 403 }));
  },
  credentials: true,
}));

// Stripe needs the raw body, so this is mounted before express.json
app.post("/api/billing/webhook", ...require("./routes/stripeWebhook"));

app.use(express.json({ limit: "100kb" }), cookieParser(), globalLimiter);
app.use((req, res, next) => { req.body ??= {}; next(); });   // Express 5 leaves body undefined when none was sent
app.use(originGuard);

app.use("/api/auth", require("./routes/auth"));
app.use("/api/ai", require("./routes/ai"));
app.use("/api/tasks", require("./routes/tasks"));
app.use("/api/projects", require("./routes/projects"));
app.use("/api/billing", require("./routes/billing"));
app.use("/api/org", require("./routes/org"));
app.use("/api/founder", require("./routes/founder"));

app.use((req, res) => res.status(404).json({ error: "Route not found" }));
app.use(errorHandler);

module.exports = app;
