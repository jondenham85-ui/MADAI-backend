const isProd = process.env.NODE_ENV === "production";
const clean = (s) => (s || "").trim().replace(/\/+$/, "");

const allowedOrigins = [
  process.env.FRONTEND_URL,
  ...(process.env.EXTRA_ORIGINS || "").split(","),
  "https://madmadisonai.com",
  "https://www.madmadisonai.com",
  ...(isProd ? [] : ["http://localhost:3000"]),
].map(clean).filter(Boolean);

const frontendUrl = () => clean(process.env.FRONTEND_URL) || "http://localhost:3000";

module.exports = { allowedOrigins, frontendUrl };
