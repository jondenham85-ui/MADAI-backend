// Single source of truth for plans, limits and Mad Packs. Edit numbers here only.
const ALL_KINDS = ["general", "website", "webapp", "code", "business"];

const PLANS = {
  // ---- Consumer ----  (tasks and builds reset monthly, UTC calendar month; chat resets daily)
  free:    { label: "Free",    tier: "consumer", rank: 0, tasksPerMonth: 20,   buildsPerMonth: 3,   chatPerDay: 25,   projects: 1,   seats: 1,  buildKinds: ["website"] },
  starter: { label: "Starter", tier: "consumer", rank: 1, tasksPerMonth: 100,  buildsPerMonth: 15,  chatPerDay: 150,  projects: 5,   seats: 1,  buildKinds: ["website"] },
  pro:     { label: "Pro",     tier: "consumer", rank: 2, tasksPerMonth: 1000, buildsPerMonth: 60,  chatPerDay: 500,  projects: 25,  seats: 1,  buildKinds: ALL_KINDS },
  // ---- Business (limits are per member; seats include the owner) ----
  team:     { label: "Team",     tier: "business", rank: 3, tasksPerMonth: 2000,  buildsPerMonth: 120, chatPerDay: 600,  projects: 50,  seats: 5,  buildKinds: ALL_KINDS },
  business: { label: "Business", tier: "business", rank: 4, tasksPerMonth: 5000,  buildsPerMonth: 300, chatPerDay: 1000, projects: 100, seats: 15, buildKinds: ALL_KINDS },
  growth:   { label: "Growth",   tier: "business", rank: 5, tasksPerMonth: 10000, buildsPerMonth: 900, chatPerDay: 2000, projects: 250, seats: 50, buildKinds: ALL_KINDS },
  // ---- Internal: the founders (never purchasable, never stored in User.plan) ----
  founder: { label: "Founder", tier: "internal", rank: 99, tasksPerMonth: 1e6, buildsPerMonth: 1e5, chatPerDay: 1e5, projects: 1e5, seats: 1, buildKinds: ALL_KINDS },
};

// plan -> env var holding its Stripe recurring Price ID
const PAID_PLANS = {
  starter: "STRIPE_STARTER_PRICE_ID",
  pro: "STRIPE_PRO_PRICE_ID",
  team: "STRIPE_TEAM_PRICE_ID",
  business: "STRIPE_BUSINESS_PRICE_ID",
  growth: "STRIPE_GROWTH_PRICE_ID",
};

// Mad Packs: one-time purchases of extra task + build credits. Used only after the monthly
// allowance runs out, and they never expire.
const MADPACKS = {
  small:  { label: "Mad Pack S", tasks: 25,  builds: 3,  env: "STRIPE_MADPACK_SMALL_PRICE_ID" },
  medium: { label: "Mad Pack M", tasks: 100, builds: 10, env: "STRIPE_MADPACK_MEDIUM_PRICE_ID" },
  large:  { label: "Mad Pack L", tasks: 500, builds: 50, env: "STRIPE_MADPACK_LARGE_PRICE_ID" },
};

const ASSIGNABLE = Object.keys(PLANS).filter((k) => k !== "founder");
const isBusinessPlan = (p) => PLANS[p]?.tier === "business";
const bestPlan = (a, b) => ((PLANS[b]?.rank ?? -1) > (PLANS[a]?.rank ?? -1) ? b : a);

function effectivePlan(user, org) {
  if (user.role === "founder") return "founder";
  let plan = user.plan || "free";
  if (org && org.plan && org.plan !== "free") plan = bestPlan(plan, org.plan);
  return plan;
}

function planFromPriceId(id) {
  if (!id) return null;
  for (const [plan, env] of Object.entries(PAID_PLANS)) if (process.env[env] === id) return plan;
  return null;
}

function publicPlans() {
  return {
    plans: ASSIGNABLE.map((key) => {
      const { label, tier, tasksPerMonth, buildsPerMonth, chatPerDay, projects, seats, buildKinds } = PLANS[key];
      return { key, label, tier, tasksPerMonth, buildsPerMonth, chatPerDay, projects, seats, buildKinds,
        available: key === "free" || Boolean(process.env[PAID_PLANS[key]]) };
    }),
    madPacks: Object.entries(MADPACKS).map(([key, p]) => ({
      key, label: p.label, tasks: p.tasks, builds: p.builds, available: Boolean(process.env[p.env]),
    })),
  };
}

module.exports = { PLANS, PAID_PLANS, MADPACKS, ASSIGNABLE, isBusinessPlan, bestPlan, effectivePlan,
  planFromPriceId, publicPlans };
